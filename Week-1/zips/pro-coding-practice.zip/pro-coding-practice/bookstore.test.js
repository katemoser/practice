it('should price books correctly', function () {
  // TODO    
});

// TODO: additional tests here ...
