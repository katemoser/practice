// add whatever parameters you deem necessary & write doc comment
function canConstructWord() {
}
